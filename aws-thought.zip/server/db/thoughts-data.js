let User = {
    "username": {
        "S": "grep"
    },
    "email": {
        "S": "groot@gmail.com"
    },
    "thoughts": {
        "L": [
            {
                "M": {
                    "createdAt": {
                        "N": "2019-03-16"
                    },
                    "thoughtText": {
                        "S": "I think therefore I am"
                    }
                },
                "M": {
                    "createdAt": {
                        "N": "2020-03-17"
                    },
                    "thoughtText": {
                        "S": "Be the change"
                    }

                }
            }
        ]
    }

}
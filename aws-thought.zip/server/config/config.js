// Config for local DynamoDB instance

module.exports = {
  region: 'us-east-2',
  aws_dynamodb_table: 'Thoughts',
  endpoint: 'http://localhost:8080',
  accessKeyId: 'xxxx',
  secretAccessKey: 'xxxx'
};

